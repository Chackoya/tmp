package com.example.cryptocurrencytracker.ui;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.cryptocurrencytracker.CoinModel;
import com.example.cryptocurrencytracker.R;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;


public class FragmentCoinDetails extends Fragment {
    ViewModel vm;

    String allText= "";
    TextView tv_name_coin;
    BarChart barChart;
    BarData barData;
    BarDataSet barDataSet;

    ArrayList barentries;
    View myView;


    public FragmentCoinDetails() {
        setHasOptionsMenu(true);
    }

    public static FragmentCoinDetails newInstance() {
        return new FragmentCoinDetails();
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.frag2, container, false);
        vm= new ViewModelProvider(requireActivity()).get(ViewModel.class);
        myView=v;
        setHasOptionsMenu(true);
        //getData();
        tv_name_coin = (TextView) v.findViewById(R.id.tv_name_coin);

        if (vm.getChoice().getValue() != null){
            tv_name_coin.setText(vm.getChoice().getValue().getName());
        }
        getData_from_geckoAPI();


        return v;

    }

    private void getData(){
        barentries=new ArrayList<>();
        barentries.add(new BarEntry(1f, 8));
        barentries.add(new BarEntry(4f, 5));
        barentries.add(new BarEntry(3f, 12));
        barentries.add(new BarEntry(10f, 12));

    }
    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        MenuInflater menuInflater = getActivity().getMenuInflater();
        menuInflater.inflate(R.menu.save_btn,menu);
        menuInflater.inflate(R.menu.back_btn,menu);
        //MenuItem searchMenuItem = menu.findItem(R.id.search);

        super.onCreateOptionsMenu(menu, inflater);
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        super.onOptionsItemSelected(item);
        if(item.getItemId() == R.id.back){
            // reset the choice
            vm.setChoice(null);

            FragmentTransaction ft = getActivity().getSupportFragmentManager().beginTransaction();
            ft.replace(R.id.container, new MainFragment());
            ft.commit();

            return true;
        }
        else{
            if(item.getItemId() == R.id.save){
                // reset the choice
                getData_from_geckoAPI();
                System.out.println("Done");
                return true;
            }
        }
        return false;
    }

    private void getData_from_geckoAPI(){
        // creating a variable for storing our string.

        String url = "https://api.coingecko.com/api/v3/coins/"+tv_name_coin.getText().toString().toLowerCase()+"/market_chart?vs_currency=usd&days=4&interval=daily";
        // creating a variable for request queue.
        System.out.println("URL:"+url);
        RequestQueue queue = Volley.newRequestQueue(getActivity());
        // making a json object request to fetch data from API.
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {
                    // extracting data from json.
                    barChart=myView.findViewById(R.id.barchart);
                    barentries=new ArrayList<>();
                    //ArrayList<Integer> dataArray =new ArrayList<>();
                    JSONArray dataArray = response.getJSONArray("prices");
                    //System.out.println("---------------RESPONSE COINGECKO------------------------------->>"+response+ " JSON:"+dataArray);

                    for (int i = 0; i < dataArray.length(); i++) {
                        JSONArray innerArray = dataArray.optJSONArray(i);
                        Float x = ((Double)innerArray.get(1)).floatValue();
                        Double dy = ((Long)innerArray.get(0)).doubleValue();
                        System.out.println( " zzzé22"+dy.getClass());
                        Float y = ((Double)dy).floatValue();
                        System.out.println( " zzz"+y.getClass());
                        barentries.add(new BarEntry(x, y));


                    }



                    barDataSet = new BarDataSet(barentries,"Dataset");
                    barData = new BarData(barDataSet);
                    barChart.setData(barData);

                    barDataSet.setColors(ColorTemplate.MATERIAL_COLORS);
                    barDataSet.setValueTextColor(Color.BLACK);
                    barDataSet.setValueTextSize(18f);



                } catch (Exception e) {
                    // handling json exception.
                    e.printStackTrace();
                    Toast.makeText(getActivity(), "Something went wrong parsing the data from the API. Please try again later", Toast.LENGTH_SHORT).show();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                // displaying error response when received any error.
                Toast.makeText(getActivity(), "Something went wrong", Toast.LENGTH_SHORT).show();

            }
        });
        // calling a method to add our
        // json object request to our queue.
        queue.add(jsonObjectRequest);
    }
}
