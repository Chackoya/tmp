package com.example.cryptocurrencytracker.ui;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.cryptocurrencytracker.CoinModel;

import java.util.List;

public class ViewModel extends AndroidViewModel {

    private MutableLiveData<CoinModel> choice = new MutableLiveData<>();

    //private NoteRepository repository;

    //
    // live data where all the notes are
    //private LiveData<List<Ent_Note>> allCourses;

    public ViewModel(@NonNull Application application) {
        super(application);
    }
    public void setChoice(CoinModel i){
        choice.setValue(i);
    }

    public LiveData<CoinModel> getChoice() {
        return choice;
    }

}
